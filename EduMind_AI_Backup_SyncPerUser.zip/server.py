"""
EduMind AI - Unified Application & Database Server
Combines High-Performance Static Web Serving with SQLite REST API.
Port: 8080
"""

import http.server
import socketserver
import json
import urllib.parse
import os
import sys

import database

PORT = 8080
WEB_DIR = os.path.dirname(os.path.abspath(__file__))

class EduMindHandler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=WEB_DIR, **kwargs)

    def _send_json(self, data, status=200):
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
        self.end_headers()
        self.wfile.write(body)

    def _read_body_json(self):
        try:
            length = int(self.headers.get("Content-Length", 0))
            if length > 0:
                raw = self.rfile.read(length).decode("utf-8")
                return json.loads(raw)
        except Exception as e:
            print("Error parsing JSON body:", e)
        return {}

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
        self.end_headers()

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path

        # ----------------- REST API ROUTES -----------------
        if path.startswith("/api/"):
            if path == "/api/users":
                users = database.get_all_users()
                return self._send_json({"success": True, "users": users})

            elif path == "/api/quizzes":
                quizzes = database.get_all_quizzes()
                return self._send_json({"success": True, "quizzes": quizzes})

            elif path == "/api/attempts":
                query = urllib.parse.parse_qs(parsed.query)
                uid = query.get("userId", [None])[0]
                attempts = database.get_all_attempts(user_id=uid)
                return self._send_json({"success": True, "attempts": attempts})

            elif path == "/api/user-stats":
                query = urllib.parse.parse_qs(parsed.query)
                uid = query.get("userId", [""])[0]
                stats = database.get_user_stats(uid)
                return self._send_json({"success": True, "stats": stats})

            elif path == "/api/knowledge-gaps":
                gaps = database.get_knowledge_gaps()
                return self._send_json({"success": True, "gaps": gaps})

            elif path == "/api/roadmap":
                roadmap = database.get_active_roadmap()
                return self._send_json({"success": True, "roadmap": roadmap})

            elif path == "/api/chat":
                messages = database.get_chat_history()
                return self._send_json({"success": True, "messages": messages})

            elif path == "/api/stats":
                users = database.get_all_users()
                attempts = database.get_all_attempts()
                quizzes = database.get_all_quizzes()
                total_users = len(users)
                active_users = sum(1 for u in users if u.get("status") == "active")
                pro_users = sum(1 for u in users if u.get("plan") == "Pro")
                locked_users = sum(1 for u in users if u.get("status") == "locked")
                return self._send_json({
                    "success": True,
                    "stats": {
                        "totalUsers": total_users,
                        "activeUsers": active_users,
                        "proUsers": pro_users,
                        "lockedUsers": locked_users,
                        "totalQuizzes": len(quizzes),
                        "totalAttempts": len(attempts)
                    }
                })

            elif path == "/api/notes":
                query = urllib.parse.parse_qs(parsed.query)
                uid = query.get("userId", ["local_user"])[0]
                users = database.get_all_users()
                user = next((u for u in users if u["id"] == uid), None)
                return self._send_json({"success": True, "notes": user.get("notes", "") if user else ""})

            else:
                return self._send_json({"error": "Endpoint not found"}, status=404)

        # ----------------- STATIC FILE SERVING -----------------
        return super().do_GET()

    def do_POST(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        body = self._read_body_json()

        if path == "/api/auth/login":
            email = body.get("email", "").strip()
            password = body.get("password", "")
            user = database.authenticate_user(email, password)
            if user:
                return self._send_json({"success": True, "user": user})
            return self._send_json({"success": False, "error": "Email hoặc mật khẩu không chính xác."}, status=401)

        elif path == "/api/auth/register":
            name = body.get("name", "").strip()
            email = body.get("email", "").strip()
            password = body.get("password", "")
            if not email or not password:
                return self._send_json({"success": False, "error": "Vui lòng nhập đủ thông tin."}, status=400)
            created = database.create_user({"name": name, "email": email, "password": password})
            return self._send_json({"success": True, "user": created})

        elif path == "/api/users":
            created = database.create_user(body)
            return self._send_json({"success": True, "user": created}, status=201)

        elif path == "/api/quizzes":
            created = database.create_quiz(body)
            return self._send_json({"success": True, "quiz": created}, status=201)

        elif path == "/api/attempts":
            created = database.create_attempt(body)
            return self._send_json({"success": True, "attempt": created}, status=201)

        elif path == "/api/chat":
            msg = database.add_chat_message(body)
            return self._send_json({"success": True, "message": msg}, status=201)

        elif path == "/api/notes":
            uid = body.get("userId", "local_user")
            notes = body.get("notes", "")
            database.update_user(uid, {"notes": notes})
            return self._send_json({"success": True})

        elif path == "/api/survey":
            uid = body.get("userId", "local_user")
            survey_json = json.dumps(body.get("survey", {}), ensure_ascii=False)
            database.update_user(uid, {"survey": survey_json})
            return self._send_json({"success": True})

        elif path == "/api/db/seed":
            database.init_db()
            return self._send_json({"success": True, "message": "Database reset & seeded successfully."})

        return self._send_json({"error": "Endpoint not found"}, status=404)

    def do_PUT(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        body = self._read_body_json()

        if path.startswith("/api/users/"):
            uid = path.replace("/api/users/", "").strip()
            database.update_user(uid, body)
            return self._send_json({"success": True, "id": uid})

        return self._send_json({"error": "Endpoint not found"}, status=404)

    def do_DELETE(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path

        if path.startswith("/api/users/"):
            uid = path.replace("/api/users/", "").strip()
            database.delete_user(uid)
            return self._send_json({"success": True, "deleted": uid})

        return self._send_json({"error": "Endpoint not found"}, status=404)

def run():
    database.init_db()
    print("=" * 60)
    print(f" EduMind AI - Server with SQLite Database running on port {PORT}")
    print(f" Database: {database.DB_PATH}")
    print(f" Open browser: http://localhost:{PORT}")
    print("=" * 60)
    sys.stdout.flush()

    socketserver.TCPServer.allow_reuse_address = True
    with socketserver.TCPServer(("", PORT), EduMindHandler) as httpd:
        httpd.serve_forever()

if __name__ == "__main__":
    run()
